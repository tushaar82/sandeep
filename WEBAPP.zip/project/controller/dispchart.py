from project import app
from project.models import NewPrinter
from project.models import DispChart
import pandas as pd
import numpy as np

from flask import render_template, request

@app.route('/dispchart',methods=['GET','POST'])
def displaychart():
	initialAmount = 10000
	pl = 2758
	drawdown = 6.5
	totalGain = 12758
	return render_template('displaychart.html', initialAmount=initialAmount, pl=pl, drawdown=drawdown, totalGain = totalGain)


