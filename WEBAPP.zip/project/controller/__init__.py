from project import app
from project.models import Printer
from flask import render_template
import project.controller.printer
import project.controller.newprinter
import project.controller.dispchart

