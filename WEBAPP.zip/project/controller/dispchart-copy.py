from project import app
from project.models import NewPrinter
from project.models import DispChart
import pandas as pd
import numpy as np

from flask import render_template, request

@app.route('/dispchart',methods=['GET','POST'])
def displaychart():
	initialAmount = 10000
	pl = 275800
	drawdown = 106100
	totalGain = 80600
	return render_template('displaychart.html', initialAmount=initialAmount, pl=pl, drawdown=drawdown, totalGain = totalGain)


