from flask import flash

class DispChart(object):

    def show_chart(self,text):
        if text=='':
            flash("You didn't enter any text to flash")
        else:
            flash(text)
