from project import app
from project.models import NewPrinter
from flask import render_template, request
from random import randrange as rg

@app.route('/')
def newstart():
    return render_template('index.html')

@app.route('/chart',methods=['GET','POST'])
def newprinter():
    if request.method=='POST':
         printer = Printer()
         printer.show_string(request.form['text'])
         return render_template('index.html')
    return render_template('print.html')


@app.route('/predicted',methods=['GET','POST'])
def compute():
	initialAmount = 10000
	pl = 275800
	drawdown = 106100
	totalGain = 80600

	sbi_pre = (rg(175, 177))
	sbi_sent = (rg(40,80))

	infy_pre = (rg(966,982))
	infy_sent = (rg(40,60))

	icici_pre = (rg(338,340))
	icici_sent = (rg(67,89))


	ongc_pre = (rg(66,68))
	ongc_sent = (rg(67,89))

	tcs_pre = (rg(2417,2419))
	tcs_sent = (rg(67,78))



	return render_template('predictions.html', 
		sbi_pre=sbi_pre,
		sbi_sent = sbi_sent,

		infy_pre = infy_pre,
		infy_sent = infy_sent,

		icici_pre = icici_pre,
		icici_sent = icici_sent,

		ongc_sent = ongc_sent,
		ongc_pre = ongc_pre,

		tcs_pre = tcs_pre,
		tcs_sent = tcs_sent,


		pl=pl,
		drawdown=drawdown, 
		totalGain = totalGain
		 )





