from project import app
from project.models.printer import *
from project.models.newprinter import *
from project.models.dispchart import *



